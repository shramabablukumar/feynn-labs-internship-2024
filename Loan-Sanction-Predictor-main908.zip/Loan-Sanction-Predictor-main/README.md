# Loan-Sanction-Predictor
The Loan Sanction Predictor project uses machine learning to analyze financial histories, incomes, and credit scores, aiming to transform how loans are sanctioned.
